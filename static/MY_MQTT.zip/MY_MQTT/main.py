import ssl
import uasyncio as asyncio
import re
from machine import UART, Pin
from mqtt_as.mqtt_as import MQTTClient
from mqtt_as.mqtt_local import wifi_led, blue_led, config
from config import *

# ==== UART Setup ==== 
uart = UART(2, baudrate=9600, tx=17, rx=16)

# ==== Protocol Definitions ==== 
MAX_MESSAGE_LEN = 64
team = [b'H', b'M', b'A', b'S']
id = b'M'
broadcast = b'X'
bs = '\\'
VALID_MESSAGE_TYPES = {
    0x00: [0x00],
    0x01: [0x00, 0x01],
    0x02: [0x00, 0x01, 0x02],
    0x03: [0x00, 0x01, 0x02]
}

led = Pin(2, Pin.OUT)

# ==== MQTT Callback (Updated) ==== 
def sub_cb(topic, msg, retained):
    print(f"[MQTT] Topic: {topic.decode()} | Message: {msg.decode('latin1')} | Retained: {retained}")
    
    # Ensure message starts with AZ and ends with YB
    # Modify this section to match the correct format

    # Construct message with AZ as prefix, sender, receiver, message type, data, and YB as suffix
    # Ensure msg_type is a single byte and data is handled correctly
    sender = b'M'  # Example sender, change as needed
    receiver = b'H'  # Example receiver, change as needed
    # msg_type = msg[:4]  # Example message type, change as needed
    msg_type  = bytes([int(msg[0:1])])
    msg_data =bytes([int(msg[1:2])])
    # Format the message

    message = b"AZ" + sender + receiver + msg_type + msg_data + b"YB"
    
    # Now send the message
    uart.write(message)  # Send the message over UART
    print(f"Sent: {message}")
    
# ==== Message Handler ==== 
def handle_message(message):
    try:
        if len(message) < 7:
            print("[UART] Message too short, deleting.")
            return

        prefix = message[:2]
        sender = message[2:3]
        receiver = message[3:4]
        suffix = message[-2:]

        if prefix != b"AZ" or suffix != b"YB":
            print("[UART] Invalid format, deleting.")
            return

        if sender == id:
            print("[UART] Deleted own message.")
            return

        if sender not in team:
            print("[UART] Invalid sender, deleting.")
            return

        if receiver not in team and receiver != broadcast:
            print("[UART] Invalid receiver, deleting.")
            return

        if receiver == id or receiver == broadcast:
            print(f"[UART] Received valid message from {sender}: {repr(message)}")
            led.value(not led.value())
            asyncio.create_task(client.publish(TOPIC_PUB, message, qos=1))

        elif receiver != id:
            print(f"[UART] Forwarding message to {receiver}")
            uart.write(message)

    except Exception as e:
        print(f"[UART] Error processing message: {e}")

# ==== UART Receiver ==== 
async def uart_listener():
    stream = b''
    message = b''
    receiving = False

    while True:
        c = uart.read(1)
        if c:
            stream += c
            if stream[-2:] == b"AZ":
                message = b"AZ"
                receiving = True
            elif receiving:
                message += c
                if stream[-2:] == b"YB":
                    receiving = False
                    handle_message(message)
                    stream = b''
                    message = b''
                elif len(message) > MAX_MESSAGE_LEN:
                    print("[UART] Message too long, dropping.")
                    message = b''
                    receiving = False
                    stream = b''
        await asyncio.sleep_ms(10)

# ==== MQTT Heartbeat ==== 
async def heartbeat():
    s = True
    while True:
        await asyncio.sleep_ms(500)
        blue_led(s)
        s = not s

async def wifi_han(state):
    wifi_led(not state)
    print('[WiFi]', 'Connected' if state else 'Disconnected')
    await asyncio.sleep(1)

async def conn_han(client):
    await client.subscribe(TOPIC_SUB, 1)

# ==== MQTT Main ==== 
async def main(client):
    try:
        await client.connect()
    except OSError:
        print('[MQTT] Connection failed.')
        return

    asyncio.create_task(uart_listener())

    while True:
        await asyncio.sleep(5)
        await client.publish(TOPIC_HB, 'ESP32 MQTT Alive', qos=1)

# ==== MQTT Config ==== 
config['server'] = MQTT_SERVER
config['ssid'] = WIFI_SSID
config['wifi_pw'] = WIFI_PASSWORD
config['ssl'] = True

with open('certs/student_key.pem', 'rb') as f:
    key_data = f.read()
with open('certs/student_crt.pem', 'rb') as f:
    cert_data = f.read()
with open('certs/ca_crt.pem', 'rb') as f:
    ca_data = f.read()

ssl_params = {
    "cert": cert_data,
    "key": key_data,
    "cadata": ca_data,
    "server_hostname": MQTT_SERVER,
    "cert_reqs": ssl.CERT_REQUIRED
}

config.update({
    'ssl_params': ssl_params,
    'time_server': MQTT_SERVER,
    'time_server_timeout': 10,
    'subs_cb': sub_cb,
    'wifi_coro': wifi_han,
    'connect_coro': conn_han,
    'clean': True,
    'user': MQTT_USER,
    'password': MQTT_PASSWORD
})

MQTTClient.DEBUG = True
client = MQTTClient(config)

asyncio.create_task(heartbeat())
try:
    asyncio.run(main(client))
finally:
    client.close()
    asyncio.new_event_loop()
